2.0.0
-----
* Rewrite for new petfinder API v2.0 which uses JSON and oauth2

1.0.4
-----
* Update gem dependencies to latest versions

1.0.3
-----
* Adding inspect methods and rake console tasks (JessSumner)

1.0.2
-----
* Add contact object to pet (lynnaloo)

1.0.1
-----
* Update gem dependencies and versions

1.0.0
-----
* New gem dependencies: nokogiri and excon
* `Pet#pictures` is now `Pet#photos`
* `Pet#description_sanitized` offers html-free description compared to `Pet#description`
* Cleaned up internals
